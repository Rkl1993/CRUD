let id="no";
var arr = [

];
let current_page = 1;
let rows = 5;
var list_element = document.getElementById('root');
var pagination_element = document.getElementById('pagination');
selectData();
function manageData(){
	document.getElementById('msg').innerHTML=""; 
	let name=document.getElementById('name').value;
	if(name==''){
		document.getElementById('msg').innerHTML='Please enter your name';
	}else{
		// console.log(id);
		if(id=='no'){
			let arr=getCrudData();  //Check data available or not in local storage	
			if(arr==null){    
				let data=[name];  
				setCrudData(data); // add data in localstorage
			}else{
				arr.push(name);
				setCrudData(arr);
			}
			document.getElementById('msg').innerHTML='Data added';
		}else{
			let arr=getCrudData();
			arr[id]=name;
			setCrudData(arr);
			document.getElementById('msg').innerHTML='Data updated';
		}
		document.getElementById('name').value='';
		selectData();
	}
	id='no';
}

function selectData(){
	let arr=getCrudData();
	if(arr!=null){
		let html='';
		let sno=1;
		for(let k in arr){
			html=html+`<tr><td>${sno}</td><td>${arr[k]}</td><td><a href="javascript:void(0)" onclick="editData(${k})">Edit</a>&nbsp;<a href="javascript:void(0)" onclick="deleteData(${k})">Delete</a></td></tr>`;
			sno++;
		}
		document.getElementById('root').innerHTML=html;
		list_element = document.getElementById('root');
		DisplayList(arr, list_element, rows, current_page);
		SetupPagination(arr, pagination_element, rows);
		
	}
}
function editData(rid){
	id=rid;
	let arr=getCrudData();
	document.getElementById('name').value=arr[rid];	
}
function deleteData(rid){
	let arr=getCrudData();
	arr.splice(rid,1);
	setCrudData(arr);
	selectData();
}
function getCrudData(){
	let arr=JSON.parse(localStorage.getItem('crud'));
	return arr;
}

function setCrudData(arr){
	localStorage.setItem('crud',JSON.stringify(arr));
}
/**
 * Pagination Code
 */
 
 function DisplayList (items, wrapper, rows_per_page, page) {
	 wrapper.innerHTML = "";
	 page--;
 
	 let start = rows_per_page * page;
	 let end = start + rows_per_page;
	 let paginatedItems = items.slice(start, end);
	 let html='';	
	 let k = start+1;
	//debugger;
	 for (let i = 0; i < paginatedItems.length; i++) {
		 let item = paginatedItems[i];
		 html=html+`<tr><td>${k}</td><td>${item}</td><td><a href="javascript:void(0)" onclick="editData(${k-1})">Edit</a>&nbsp;<a href="javascript:void(0)" onclick="deleteData(${k-1})">Delete</a></td></tr>`;
		 document.getElementById('root').innerHTML=html;
		 k++;		
	 }
 }
 
 function SetupPagination (items, wrapper, rows_per_page) {
	 wrapper.innerHTML = "";
 
	 let page_count = Math.ceil(items.length / rows_per_page);
	 for (let i = 1; i < page_count + 1; i++) {
		 let btn = PaginationButton(i, items);
		 wrapper.appendChild(btn);
	 }
 }
 
 function PaginationButton (page, items) {
	 let button = document.createElement('button');
	 button.innerText = page;
 
	 if (current_page == page) button.classList.add('active');
 
	 button.addEventListener('click', function () {
		 current_page = page;
		 DisplayList(items, list_element, rows, current_page);		
	 });
 
	 return button;
 }
 
